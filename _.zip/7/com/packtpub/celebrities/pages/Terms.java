package com.packtpub.celebrities.pages;

public class Terms {

}
