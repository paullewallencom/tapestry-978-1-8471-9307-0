package com.packtpub.celebrities.pages;

import java.util.Date;

/**
 * Start page of application celebrities.
 */
public class Start
{
	public Date getCurrentTime() 
	{ 
		return new Date(); 
	}
}