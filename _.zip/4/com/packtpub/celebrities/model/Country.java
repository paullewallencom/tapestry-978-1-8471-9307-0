package com.packtpub.celebrities.model;

public enum Country {
	GERMANY, UK, USA
}
