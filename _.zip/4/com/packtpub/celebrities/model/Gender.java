package com.packtpub.celebrities.model;

public enum Gender {
	MALE, FEMALE
}
