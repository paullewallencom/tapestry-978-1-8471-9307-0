package com.packtpub.celebrities.model;

public enum Occupation {
	ACTOR, ACTRESS, ARTIST, BUSINESSMAN, COMPOSER, 
    MUSICIAN, POLITICIAN, SCIENTIST, SINGER, WRITER
}
