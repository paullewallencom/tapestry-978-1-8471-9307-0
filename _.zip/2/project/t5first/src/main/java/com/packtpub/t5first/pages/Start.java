package com.packtpub.t5first.pages;

import java.util.Date;

/**
 * Start page of application t5first.
 */
public class Start
{
	public Date getCurrentTime() 
	{ 
		return new Date(); 
	}
}