package com.packtpub.celebrities.services;

public interface SupportedLocales {
	public String getSupportedLocales();
}
